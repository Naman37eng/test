document.addEventListener("DOMContentLoaded", async () => {
    const leaveForm = document.getElementById("leave-form");
    const pasteUse = document.getElementById("use");
    const submitButton = document.getElementById("submmit");

    try {
        const response = await fetch("/api/profile/full", { method: "GET", credentials: "include" });

        if (!response.ok) {
            throw new Error("Failed to fetch profile data");
        }

        const profile = await response.json();

        // Ensure the profile data is returned as an array and has at least one element
        if (Array.isArray(profile) && profile.length > 0) {
            const user = profile[0]; // Access the first profile in the array

            leaveForm.addEventListener("submit", async (event) => {
                event.preventDefault();
                const reason = document.getElementById("reason").value.trim();
                const startDate = document.getElementById("start-date").value;
                const endDate = document.getElementById("end-date").value;
                const leaveType = document.getElementById("leave-type").value;

                if (!reason || !startDate || !endDate || !leaveType) {
                    alert("Please fill in all the fields.");
                    return;
                }

                if (new Date(startDate) < new Date()) {
                    alert("Start date cannot be in the past.");
                    return;
                }

                if (new Date(endDate) < new Date(startDate)) {
                    alert("End date cannot be before the start date.");
                    return;
                }

                // Use user data from the profile array
                const registrationNumber = user.username;
                const studentName = user.name;
                const leaveRequest = { studentName, registrationNumber, reason, startDate, endDate, leaveType };
                console.log(leaveRequest); // Log the leave request object to verify if studentName and registrationNumber are correct


                submitButton.disabled = true;
                submitButton.textContent = "Submitting...";

                try {
                    const response = await fetch("/api/leave/leave-request", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(leaveRequest),
                    });

                    if (response.ok) {
                        alert("Leave request submitted successfully!");
                        leaveForm.reset();
                    } else {
                        const errorData = await response.json();
                        alert(errorData.message || "Failed to submit leave request.");
                    }
                } catch (error) {
                    console.error("Error submitting leave request:", error);
                    alert("Error submitting leave request. Please try again.");
                } finally {
                    submitButton.disabled = false;
                    submitButton.textContent = "Submit";
                }
            });



    // try {
        // Function to format the date into a readable format
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString("en-US", {
                weekday: "short", // short format like Mon, Tue, etc.
                year: "numeric",
                month: "short", // short month like Jan, Feb, etc.
                day: "numeric", // day as number
            });
        }

        let leaveRequestsTable = "";

        // Loop through all leave requests and create rows in the table
        profile.forEach(request => {
            let backgroundColor = "#0000FF";
            if (request.status === "Approved") {
                // font-weight : "bold";
                backgroundColor = "#e0ffe0"; // Very light green
            } else if (request.status === "Rejected") {
                backgroundColor = "#ffe0e0"; // Very light red
            } else if (request.status === "Pending") {
                backgroundColor = "#C0C0C0";
            } else {
                backgroundColor = "#ffffff"; // No status, default white
            }

            leaveRequestsTable += `
                <tr style="background-color: ${backgroundColor};">
                <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Status</td>
                <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">${request.status || 'No status available'}</td>
                </tr>
                <tr style="background-color: ${backgroundColor};">
                <td style="border: 1px solid #ddd; padding: 8px;">Leave Start Date</td>
                <td style="border: 1px solid #ddd; padding: 8px;">${request.startDate ? formatDate(request.startDate) : 'No leave request'}</td>
                </tr>
                <tr style="background-color: ${backgroundColor};">
                    <td style="border: 1px solid #ddd; padding: 8px;">Leave End Date</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${request.endDate ? formatDate(request.endDate) : 'No leave request'}</td>
                </tr>
            `;
        });

        pasteUse.innerHTML = `
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Field</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Details</th>
                    </tr>
                </thead>
                <tbody>
                <h4 class="text-3xl font-bold">Leave Request History:</h4>
                    ${leaveRequestsTable}
                </tbody>
            </table>
        `;
    } else {
        console.error("No profile data found");
        alert("Error fetching profile data.");
    }
} catch (error) {
    console.error("Error fetching profile:", error);
    alert("Error fetching profile data. Please try again.");
}
});
