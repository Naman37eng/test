// student-management-system/assets/js/uploadProject.js
document.getElementById('upload-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const fileInput = document.getElementById('project-file');
    const file = fileInput.files[0];

    // Logic to upload the file (e.g., send to server)
    alert(`File ${file.name} uploaded successfully`);
});
