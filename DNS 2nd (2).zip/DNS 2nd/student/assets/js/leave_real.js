document.addEventListener("DOMContentLoaded", async () => {
    const leaveForm = document.getElementById("leave-form");
    const pasteUse = document.getElementById("use");
    const submitButton = document.getElementById("submmit");


    const response = await fetch("/api/profile/full", { method: "GET", credentials: "include" });

        if (!response.ok) {
            throw new Error("Failed to fetch profile data");
        }

        const profile = await response.json();
        console.log(profile);

    leaveForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const reason = document.getElementById("reason").value.trim();
        const startDate = document.getElementById("start-date").value;
        const endDate = document.getElementById("end-date").value;
        const leaveType = document.getElementById("leave-type").value;

        if (!reason || !startDate || !endDate || !leaveType) {
            alert("Please fill in all the fields.");
            return;
        }

        if (new Date(startDate) < new Date()) {
            alert("Start date cannot be in the past.");
            return;
        }

        if (new Date(endDate) < new Date(startDate)) {
            alert("End date cannot be before the start date.");
            return;
        }
        
        // console.log("Username is: " + profile.name);
        // console.log(`${profile.registrationNumber}`);
        // console.log("Registration number is: " + profile.username);

        const registrationNumber = profile.username;
        const studentName = profile.name;
        // const studentName = sessionStorage.getItem("username");
        const leaveRequest = { studentName,registrationNumber, reason, startDate, endDate, leaveType };

        submitButton.disabled = true;
        submitButton.textContent = "Submitting...";

        try {
            const response = await fetch("/api/leave/leave-request", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(leaveRequest),
            });

            if (response.ok) {
                alert("Leave request submitted successfully!");
                leaveForm.reset();
            } else {
                const errorData = await response.json();
                alert(errorData.message || "Failed to submit leave request.");
            }
        } catch (error) {
            console.error("Error submitting leave request:", error);
            alert("Error submitting leave request. Please try again.");
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = "Submit";
        }
    });

    try {
        // const response = await fetch("/api/profile/full", { method: "GET", credentials: "include" });

        // if (!response.ok) {
        //     throw new Error("Failed to fetch profile data");
        // }

        // const profile = await response.json();
        // console.log(profile);

        // Function to format the date into a readable format
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString("en-US", {
                weekday: "short", // short format like Mon, Tue, etc.
                year: "numeric",
                month: "short", // short month like Jan, Feb, etc.
                day: "numeric", // day as number
            });
        }

        // Determine background color based on the leave status
        let backgroundColor = "";
        if (profile.status === "Approved") {
            backgroundColor = "#e0ffe0"; // Very light green
        } else if (profile.status === "Rejected") {
            backgroundColor = "#ffe0e0"; // Very light red
        } else {
            backgroundColor = "#ffffff"; // No status, default white
        }

        // Constructing the HTML table with formatted date
        pasteUse.innerHTML = `
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background-color: ${backgroundColor};">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Field</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Details</th>
                    </tr>
                </thead>
                <tbody>
                        <td style="border: 1px solid #ddd; padding: 8px;">Status</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${profile.status || 'No status available'}</td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">Leave Start Date</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${profile.startDate ? formatDate(profile.startDate) : 'No leave request'}</td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">Leave End Date</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${profile.endDate ? formatDate(profile.endDate) : 'No leave request'}</td>
                    </tr>
                </tbody>
            </table>
        `;

    } catch (error) {
        console.error("Error fetching profile or leave status:", error);
    }
});
