// routes/studentRoutes.js
const express = require("express");
const db = require("../config/db"); // Assuming you have a db connection setup in config/db.js

const router = express.Router();

// Route to get all students data
router.get("/", (req, res) => {
    const query = "SELECT * FROM student_data"; // Query to fetch all students
    db.query(query, (err, result) => {
        if (err) {
            console.error("Error fetching students:", err);
            return res.status(500).json({ error: "Failed to fetch student data" });
        }
        res.json(result); // Send the student data as JSON response
    });
});

module.exports = router;
