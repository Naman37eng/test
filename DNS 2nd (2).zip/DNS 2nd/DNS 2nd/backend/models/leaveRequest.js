// const db = require("../config/db"); // Import the database connection

// // Create a new leave request
// const createLeaveRequest = (studentName,registrationNumber, reason, startDate, endDate, leaveType) => {
//     const query = "INSERT INTO leave_requests (studentName,registrationNumber, reason, startDate, endDate, leaveType, status) VALUES (?, ?, ?, ?, ?, ?)";

//     return new Promise((resolve, reject) => {
//         db.query(query, [studentName,registrationNumber, reason, startDate, endDate, leaveType, "Pending"], (err, result) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(result);
//             }
//         });
//     });
// };

// // Get all leave requests
// const getAllLeaveRequests = () => {
//     const query = "SELECT * FROM leave_requests";

//     return new Promise((resolve, reject) => {
//         db.query(query, (err, result) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(result);
//             }
//         });
//     });
// };

// // Update the leave request status
// const updateLeaveRequestStatus = (id, status) => {
//     const query = "UPDATE leave_requests SET status = ? WHERE id = ?";

//     return new Promise((resolve, reject) => {
//         db.query(query, [status, id], (err, result) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(result);
//             }
//         });
//     });
// };

// // Get a specific leave request by ID
// async function getLeaveRequestById(id) {
//     const query = "SELECT * FROM leave_requests WHERE id = ?";
//     const [rows] = await db.query(query, [id]);
//     return rows[0];
// };


// module.exports = { createLeaveRequest, getAllLeaveRequests, updateLeaveRequestStatus };



const db = require("../config/db"); // Import the database connection

// Create a new leave request
const createLeaveRequest = (studentName, registrationNumber, reason, startDate, endDate, leaveType) => {
    const query = "INSERT INTO leave_requests (studentName, registrationNumber, reason, startDate, endDate, leaveType, status) VALUES (?, ?, ?, ?, ?, ?, ?)";

    return new Promise((resolve, reject) => {
        db.query(query, [studentName, registrationNumber, reason, startDate, endDate, leaveType, "Pending"], (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
};

// Get all leave requests
const getAllLeaveRequests = () => {
    const query = "SELECT * FROM leave_requests";

    return new Promise((resolve, reject) => {
        db.query(query, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
};

// Update the leave request status
const updateLeaveRequestStatus = (id, status) => {
    const query = "UPDATE leave_requests SET status = ? WHERE id = ?";

    return new Promise((resolve, reject) => {
        db.query(query, [status, id], (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
};

// Get a specific leave request by ID
const getLeaveRequestById = async (id) => {
    const query = "SELECT * FROM leave_requests WHERE id = ?";
    try {
        const [rows] = await db.query(query, [id]);
        return rows[0] || null; // If no result, return null
    } catch (err) {
        throw err;
    }
};

module.exports = { createLeaveRequest, getAllLeaveRequests, updateLeaveRequestStatus, getLeaveRequestById };
