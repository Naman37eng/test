document.addEventListener("DOMContentLoaded", async () => {
    try {
      // Fetch profile data using the session-stored username
      const response = await fetch("/api/profile/full", {
        method: "GET",
        credentials: "include", // Ensure cookies (session) are sent with the request
      });
  
      if (!response.ok) {
        throw new Error("Failed to fetch profile data");
      }
  
      const profile = await response.json();
  
      // Populate the profile card with the user's data
      document.querySelector(".profile-info").innerHTML = `
        <div>
          <label>Name: </label>
          <span class="value">${profile.name}</span>
        </div>
        <div>
          <label>Username: </label>
          <span class="value">${profile.username}</span>
        </div>
        <div>
          <label>Email: </label>
          <span class="value">${profile.email}</span>
        </div>
        <div>
          <label>Phone Number: </label>
          <span class="value">${profile.phone_number}</span>
        </div>
        <div>
          <label>Year: </label>
          <span class="value">${profile.year}</span>
        </div>
        <div>
          <label>Date of Birth: </label>
          <span class="value">${profile.dob}</span>
        </div>
      `;
    } catch (error) {
      console.error("Error loading profile:", error);
    }
  });
  