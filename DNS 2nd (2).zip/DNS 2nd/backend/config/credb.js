const mysql = require("mysql2");

const connection2 = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "1567",
    database: "credentials_db", // Replace with your new database name
});

connection2.connect((err) => {
    if (err) {
        console.error("Database connection failed:", err.stack);
        return;
    }
    console.log("Connected to the credentials database!");
});

module.exports = connection2;