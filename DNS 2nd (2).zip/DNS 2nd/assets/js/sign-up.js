// document.addEventListener("DOMContentLoaded", () => {
//     const signupForm = document.getElementById("signup-form");

//     signupForm.addEventListener("submit", async (event) => {
//         event.preventDefault();  // Prevent the default form submission

//         // Gather form data
//         const firstName = document.getElementById("first-name").value;
//         const lastName = document.getElementById("last-name").value;
//         const email = document.getElementById("email").value;
//         const phoneNumber = document.getElementById("phone-number").value;
//         const dob = document.getElementById("dob").value;
//         const gender = document.getElementById("gender").value;

//         // Create the user object
//         const user = {
//             firstName,
//             lastName,
//             email,
//             phoneNumber,
//             dob,
//             gender
//         };

//         try {
//             // Send data to the server
//             const response = await fetch("/api/signup", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json" },
//                 body: JSON.stringify(user),
//             });

//             if (response.ok) {
//                 alert("Sign Up Successful!");
//                 window.location.href = "/login";  // Redirect to login page after successful sign up
//             } else {
//                 throw new Error("Failed to sign up.");
//             }
//         } catch (error) {
//             console.error("Error:", error);
//             alert("Error during sign-up. Please try again.");
//         }
//     });
// });
