require("dotenv").config(); // Loads environment variables from .env file
const express = require("express");
const session = require("express-session");
const connectDB = require("./config/db"); // Database connection
const leaveRoutes = require("./routes/leaveRoutes"); // Leave request routes
const authRoutes = require("./routes/authRoutes"); // Import the auth routes
const studentRoutes = require("./routes/sudentRoutes"); // Student data routes (if needed)
const profileRoutes = require("./routes/profileRoutes");
const path = require("path");

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Session middleware for handling user sessions
// app.use(
//   session({
//     secret: process.env.SESSION_SECRET || "default-secret", // Secret key for session encryption
//     resave: false,
//     saveUninitialized: true,
//     cookie: { secure: process.env.NODE_ENV === "production" }, // Set secure cookies in production (for HTTPS)
//   })
// );

app.use(
  session({
    secret: process.env.SESSION_SECRET || "default-secret",  // The session secret from .env file
    resave: false,  // Don't resave the session if not modified
    saveUninitialized: true,  // Save uninitialized sessions (good for non-logged-in users)
    cookie: { 
      secure: process.env.NODE_ENV === "production",  // Set to true in production (requires HTTPS)
      httpOnly: true,  // Ensure cookie is only accessible via HTTP(S)
      maxAge: 1000 * 60 * 60 * 24  // Optional: set session expiration to 1 day
    }
  })
);

// Use API routes for login
app.use("/api", authRoutes); // Use the authRoutes for login

app.use("/api/profile", profileRoutes); // Profile routes

// Use API routes for leave requests
app.use("/api/leave", leaveRoutes);

// Use API routes for student data (optional)
app.use("/api/students", studentRoutes);

// Serve static frontend files (Ensure frontend files are in the correct folder)
app.use(express.static(path.join(__dirname, "../"))); // Update this path if your frontend is in a different folder

// Fallback route to serve the main HTML file (for single-page apps or catch-all routing)
app.get("*", (req, res) => {
  // res.sendFile(path.resolve(__dirname, "../index.html")); // Adjust if your index.html is in a different folder
  res.sendFile(path.resolve(__dirname, "../index.html")); // Adjust if your index.html is in a different folder
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
