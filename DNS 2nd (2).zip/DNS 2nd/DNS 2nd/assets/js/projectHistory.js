// student-management-system/assets/js/projectHistory.js
document.addEventListener('DOMContentLoaded', () => {
    const projectHistoryDiv = document.getElementById('project-history');

    // Fetch project history data (this would be replaced with actual data fetching logic)
    const projectHistory = [
        { title: 'Project 1', grade: 'A' },
        { title: 'Project 2', grade: 'B+' },
        // Add more projects as needed
    ];

    projectHistory.forEach(project => {
        const projectDiv = document.createElement('div');
        projectDiv.classList.add('project');
        projectDiv.innerHTML = `
            <h2>${project.title}</h2>
            <p>Grade: ${project.grade}</p>
            <label for="new-grade-${project.title}">New Grade:</label>
            <input type="text" id="new-grade-${project.title}" name="new-grade-${project.title}">
            <button onclick="updateGrade('${project.title}')">Update Grade</button>
        `;
        projectHistoryDiv.appendChild(projectDiv);
    });
});

function updateGrade(projectTitle) {
    const newGrade = document.getElementById(`new-grade-${projectTitle}`).value;
    // Logic to update the grade (e.g., send to server)
    alert(`Grade for ${projectTitle} updated to ${newGrade}`);
}
