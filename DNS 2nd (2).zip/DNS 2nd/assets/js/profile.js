document.addEventListener("DOMContentLoaded", async () => {
  try {
    // Fetch profile data using the session-stored username
    const response = await fetch("/api/profile/full", {
      method: "GET",
      credentials: "include", // Ensure cookies (session) are sent with the request
    });

    if (!response.ok) {
      throw new Error("Failed to fetch profile data");
    }

    const profile = await response.json();

    // Check if profile data is returned as an array and has at least one element
    if (Array.isArray(profile) && profile.length > 0) {
      // Get the first profile data from the array
      const user = profile[0];

      // Populate the profile card with the user's data
      document.querySelector(".profile-info").innerHTML = `
        <div>
          <label>Name: </label>
          <span class="value">${user.name}</span>
        </div>
        <div>
          <label>Username: </label>
          <span class="value">${user.username}</span>
        </div>
        <div>
          <label>Email: </label>
          <span class="value">${user.email}</span>
        </div>
        <div>
          <label>Phone Number: </label>
          <span class="value">${user.phone_number}</span>
        </div>
        <div>
          <label>Year: </label>
          <span class="value">${user.year}</span>
        </div>
        <div>
          <label>Date of Birth: </label>
          <span class="value">${user.dob}</span>
        </div>
      `;
    } else {
      console.error("No profile data found");
    }
  } catch (error) {
    console.error("Error loading profile:", error);
  }
});
