const express = require("express");
const router = express.Router();
const leaveRequestModel = require("../models/leaveRequest"); // Assuming leaveRequest.js is in the models folder

// Create a new leave request
router.post("/leave-request", async (req, res) => {
    try {
        const { studentName,registrationNumber, reason, startDate, endDate, leaveType } = req.body;
        const result = await leaveRequestModel.createLeaveRequest(
            studentName,
            registrationNumber,
            reason,
            startDate,
            endDate,
            leaveType
          );
          res.status(201).json({ message: "Leave request submitted successfully", result });
        } catch (err) {
            res.status(500).json({ error: "Failed to submit leave request", details: err.message });
          }
        });
        
        // Get all leave requests (for admin)
        router.get("/leave-requests", async (req, res) => {
            try {
                const result = await leaveRequestModel.getAllLeaveRequests();
                res.status(200).json(result);
              } catch (err) {
                  res.status(500).json({ error: "Failed to fetch leave requests", details: err.message });
  }
});

// Update the leave request status (for admin)
router.put("/leave-request/:id", async (req, res) => {
      const { id } = req.params;
      const { status } = req.body;
      try {
            const result = await leaveRequestModel.updateLeaveRequestStatus(id, status);
            res.status(200).json({ message: `Leave request ${status} successfully!`, result });
          } catch (err) {
                res.status(500).json({ error: `Failed to update leave request status`, details: err.message });
              }
            });
    
      

// Get a specific leave request by ID
router.get("/leave-request/:id", async (req, res) => {
  const { id } = req.params;

  try {
      const leaveRequest = await leaveRequestModel.getLeaveRequestById(id);

      if (!leaveRequest) {
          return res.status(404).json({ message: "Leave request not found" });
      }

      res.status(200).json(leaveRequest);
  } catch (err) {
      res.status(500).json({ error: "Failed to fetch leave request", details: err.message });
  }
});

      
      
      
module.exports = router;
      
      
// const express = require("express");
// const router = express.Router();
// const leaveRequestModel = require("../models/leaveRequest"); // Assuming leaveRequest.js is in the models folder
      
//       // leaveRoutes.js
//       router.post("/leave-request", (req, res) => {
//         // Ensure session exists
//         if (!req.session.username) {
//           return res.status(401).json({ error: "User not logged in." });
//         }

//         const username = req.session.username; // Fetch username from session
//         const { reason, startDate, endDate, leaveType } = req.body;
        
//         if (!reason || !startDate || !endDate || !leaveType) {
//       return res.status(400).json({ error: "All fields are required." });
//   }

//   // Query the profile table to fetch studentName
//   const profileQuery = "SELECT name FROM users WHERE username = ?";
//   db.query(profileQuery, [username], (err, profileResult) => {
//       if (err) {
//           console.error(err);
//           return res.status(500).json({ error: "Database error." });
//       }

//       if (profileResult.length === 0) {
//           return res.status(404).json({ error: "User profile not found." });
//       }

//       const studentName = profileResult[0].name;

//       // Insert the leave request into the leave_requests table
//       const leaveQuery = `
//           INSERT INTO leave_requests (username, student_name, reason, start_date, end_date, leave_type)
//           VALUES (?, ?, ?, ?, ?, ?)
//       `;
//       db.query(leaveQuery, [username, studentName, reason, startDate, endDate, leaveType], (err) => {
//           if (err) {
//               console.error(err);
//               return res.status(500).json({ error: "Database error." });
//           }
//           res.status(200).json({ message: "Leave request submitted successfully!" });
//       });
//   });
// });
