const express = require("express");
const router = express.Router();
const credb = require("../config/credb"); // Import your credentials DB connection

// POST route for login
router.post("/login", (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
    }
    
    // Query the database to check the username and password
    const query = "SELECT * FROM users WHERE username = ? AND password = ?";
    credb.query(query, [username, password], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: "Database error" });
        }
        
        if (result.length === 0) {
            return res.status(401).json({ error: "Invalid username or password" });
        }
        
        // User found, now include the role in the response
        const user = result[0];
    const role = user.role;

    // You can also store the role in the session for later use
    req.session.role = role;

    req.session.username = user.username;
    
    // Respond with the role and redirection URL based on role
    let redirectTo = "/student/dashboard.html"; // Default redirect for students
    if (username === "0000000000") {
        redirectTo = "/admin/dashboard.html"; // Admin dashboard
    }
    
    res.status(200).json({ role, redirectTo }); 
    console.log(req.session);  // Check if session variables are set
});
});

module.exports = router;

// const express = require("express");
// const bcrypt = require("bcrypt");  // Assuming password is hashed using bcrypt
// const router = express.Router();
// const db = require("../config/credb"); // Database connection

// // POST route for login
// router.post("/login", (req, res) => {
//   const { username, password } = req.body;

//   if (!username || !password) {
//     return res.status(400).json({ error: "Username and password are required" });
//   }

//   // Query the database to check if the username exists
//   const query = "SELECT * FROM users WHERE username = ?";
//   db.query(query, [username], (err, result) => {
//     if (err) {
//       console.error(err);
//       return res.status(500).json({ error: "Database error" });
//     }

//     if (result.length === 0) {
//       return res.status(401).json({ error: "Invalid username or password" });
//     }

//     const user = result[0];

//     // Check if the provided password matches the stored password
//     bcrypt.compare(password, user.password, (err, isMatch) => {
//       if (err) {
//         console.error(err);
//         return res.status(500).json({ error: "Error comparing passwords" });
//       }

//       if (!isMatch) {
//         return res.status(401).json({ error: "Invalid username or password" });
//       }

//       // If password is correct, store the username in the session
//       req.session.username = user.username;
//       if(username == "0000000000"){
//           res.status(200).json({
//             message: "Login successful",
//             redirectTo: "/admin/dashboard.html", // Redirect to the profile page after login
//         });
//     }else{
//             res.status(200).json({
//               message: "Login successful",
//               redirectTo: "/student/dashboard.html", // Redirect to the profile page after login
//           });

//         }
//     });
//   });
// });

// module.exports = router;
