document.addEventListener("DOMContentLoaded", async () => {
    const tableBody = document.getElementById("leave-requests");

    // Fetch leave requests from the backend
    async function fetchLeaveRequests() {
        try {
            const response = await fetch("/api/leave/leave-requests");
            if (!response.ok) throw new Error("Failed to fetch leave requests");

            const leaveRequests = await response.json();


            // Clear the table content
            tableBody.innerHTML = "";
            leaveRequests.forEach((request) => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td class="border px-4 py-2">${request.studentName}</td>
                    <td class="border px-4 py-2">${request.reason}</td>
                    <td class="border px-4 py-2">${request.startDate}</td>
                    <td class="border px-4 py-2">${request.endDate}</td>
                    <td class="border px-4 py-2">${request.leaveType}</td>
                    <td class="border px-4 py-2">${request.status || "Pending"}</td>
                    <td class="border px-4 py-2 action-buttons">
                        ${request.status === "Approved" || request.status === "Rejected" 
                            ? `<span class="text-${request.status === "Approved" ? "green" : "red"}-500 font-semibold">${request.status}</span>`
                            : `
                                <button class="approve-btn px-4 py-2 bg-green-500 text-white rounded-md">Approve</button>
                                <button class="reject-btn px-4 py-2 bg-red-500 text-white rounded-md">Reject</button>
                              `
                        }
                    </td>
                `;
                tableBody.appendChild(row);

                if (request.status === "Pending") {
                    // Add event listeners for approve and reject actions
                    row.querySelector(".approve-btn").addEventListener("click", () => handleAction(request.id, "Approved", row));
                    row.querySelector(".reject-btn").addEventListener("click", () => handleAction(request.id, "Rejected", row));
                }
            });
        } catch (error) {
            console.error("Error fetching leave requests:", error);
            alert("Failed to load leave requests. Please try again later.");
        }
    }

    // Handle approval or rejection of a leave request
    async function handleAction(id, status, row) {
        try {
            const response = await fetch(`/api/leave/leave-request/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ status }),
            });

            if (response.ok) {
                // Update the status in the UI
                const actionButtonsCell = row.querySelector(".action-buttons");
                actionButtonsCell.innerHTML = `<span class="text-${status === "Approved" ? "green" : "red"}-500 font-semibold">${status}</span>`;
                row.querySelector("td:nth-child(6)").textContent = status; // Update the status cell
                alert(`Leave request ${status.toLowerCase()} successfully!`);
            } else {
                const errorData = await response.json();
                throw new Error(errorData.message || "Failed to update leave request.");
            }
        } catch (error) {
            console.error("Error updating leave request:", error);
            alert(`Error updating leave request: ${error.message}`);
        }
    }



    // Initialize by fetching leave requests
    fetchLeaveRequests();
});
