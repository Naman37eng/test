const express = require("express");
const router = express.Router();
const db = require("../config/credb"); // Database connection



// GET route to fetch the profile details based on the username from the session
router.get("/full", (req, res) => {
  
  if (!req.session.username) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  
  const username = req.session.username; // Get the username from session
  console.log("Hello!", req.session);  // Check if session variables are set
  // Query to get all leave requests for the student
  const query = `
    SELECT 
      users.name, 
      users.username, 
      users.email, 
      users.phone_number, 
      users.dob, 
      users.year, 
      leave_requests.startDate, 
      leave_requests.endDate, 
      leave_requests.status
    FROM credentials_db.users users
    LEFT JOIN leave_management.leave_requests leave_requests 
      ON users.username = leave_requests.registrationNumber
    WHERE users.username = ?;
  `;

  db.query(query, [username], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Database error" });
    }

    console.log('Query result:', result);

    if (result.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    // Respond with the profile data and all leave requests
    res.status(200).json(result); // Send all leave requests
  });
});

module.exports = router;
