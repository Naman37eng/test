// Handle Chatbot Icon Click
const chatbotIcon = document.getElementById("chatbot-icon");
const chatbotContainer = document.getElementById("chatbot-container");
const closeChatbot = document.getElementById("close-chatbot");
const sendChat = document.getElementById("send-chat");
const chatInput = document.getElementById("chat-input");
const chatMessages = document.getElementById("chat-messages");

// Toggle Chatbot Visibility
chatbotIcon.addEventListener("click", () => {
    chatbotContainer.classList.toggle("hidden");
});

// Close Chatbot
closeChatbot.addEventListener("click", () => {
    chatbotContainer.classList.add("hidden");
});

// Handle Sending Messages
sendChat.addEventListener("click", () => {
    const message = chatInput.value.trim();
    if (message) {
        // Add user message to chat
        const userMessage = document.createElement("div");
        userMessage.classList.add("bg-blue-100", "p-2", "rounded", "text-right");
        userMessage.textContent = message;
        chatMessages.appendChild(userMessage);

        // Clear input
        chatInput.value = "";

        // Simulate chatbot reply
        setTimeout(() => {
            const botReply = document.createElement("div");
            botReply.classList.add("bg-gray-100", "p-2", "rounded");
            botReply.textContent = "I am here to assist you!";
            chatMessages.appendChild(botReply);

            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 500);
    }
});
